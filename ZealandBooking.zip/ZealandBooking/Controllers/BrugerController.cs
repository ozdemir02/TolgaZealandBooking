﻿using Microsoft.AspNetCore.Mvc;

namespace ZealandBooking.Controllers
{
    public class BrugerController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
