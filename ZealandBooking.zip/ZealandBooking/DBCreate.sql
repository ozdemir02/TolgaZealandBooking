CREATE TABLE [dbo].[Lokale] (
    [ID] INT IDENTITY(1,1) NOT NULL,
    [Name] NVARCHAR(MAX) NOT NULL,
    [Size] INT NOT NULL,
    [Capacity] INT NOT NULL,
    [MaxGroupsPerRoom] INT NOT NULL,
    [Equipment] NVARCHAR(MAX) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);

CREATE TABLE [dbo].[Gruppe] (
    [ID] INT IDENTITY(1,1) NOT NULL,
    [Name] NVARCHAR(MAX) NOT NULL,
    [Size] INT NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC),
    [LokaleId] INT NULL,
    CONSTRAINT [FK_Gruppe_Lokale_Id] FOREIGN KEY ([LokaleId]) REFERENCES [dbo].[Lokale] ([ID]),
);

CREATE TABLE [dbo].[Bruger] (
    [ID] INT IDENTITY(1,1) NOT NULL,
    [Role] NVARCHAR(MAX) NOT NULL,
    [Username] NVARCHAR(255) UNIQUE NOT NULL,
    [Password] NVARCHAR(MAX) NOT NULL,
    [Email] NVARCHAR(MAX) NOT NULL,
    [Description] NVARCHAR(MAX) NULL,
    [Created] DATETIME NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);

CREATE TABLE [dbo].[Booking] (
    [ID] INT IDENTITY(1,1) NOT NULL,
    [StartTime] DATETIME NOT NULL,
    [EndTime] DATETIME NOT NULL,
    [CancelDeadline] DATETIME NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC),
    [LokaleId] INT NULL,
    [BrugerId] INT NULL,
    [GruppeId] INT NULL,
    CONSTRAINT [FK_Booking_Lokale_Id] FOREIGN KEY ([LokaleId]) REFERENCES [dbo].[Lokale] ([ID]),
    CONSTRAINT [FK_Booking_Bruger_Id] FOREIGN KEY ([BrugerId]) REFERENCES [dbo].[Bruger] ([ID]),
    CONSTRAINT [FK_Booking_Gruppe_Id] FOREIGN KEY ([GruppeId]) REFERENCES [dbo].[Gruppe] ([ID]),
);

CREATE TABLE [dbo].[Studerende] (
    [ID] INT IDENTITY(1,1) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC),
    [LokaleId] INT NULL,
    [BrugerId] INT NULL,
    [GruppeId] INT NULL,
    CONSTRAINT [FK_Studerende_Lokale_Id] FOREIGN KEY ([LokaleId]) REFERENCES [dbo].[Lokale] ([ID]),
    CONSTRAINT [FK_Studerende_Bruger_Id] FOREIGN KEY ([BrugerId]) REFERENCES [dbo].[Bruger] ([ID]),
    CONSTRAINT [FK_Studerende_Gruppe_Id] FOREIGN KEY ([GruppeId]) REFERENCES [dbo].[Gruppe] ([ID]),
);

CREATE TABLE [dbo].[Underviser] (
    [ID] INT IDENTITY(1,1) NOT NULL,
    [Subject] NVARCHAR(100) NOT NULL,
    [Age] INT,
    PRIMARY KEY CLUSTERED ([ID] ASC),
    [LokaleId] INT NULL,
    [BrugerId] INT NULL,
    [GruppeId] INT NULL,
    CONSTRAINT [FK_Underviser_Lokale_Id] FOREIGN KEY ([LokaleId]) REFERENCES [dbo].[Lokale] ([ID]),
    CONSTRAINT [FK_Underviser_Bruger_Id] FOREIGN KEY ([BrugerId]) REFERENCES [dbo].[Bruger] ([ID]),
    CONSTRAINT [FK_Underviser_Gruppe_Id] FOREIGN KEY ([GruppeId]) REFERENCES [dbo].[Gruppe] ([ID]),
);

CREATE TABLE [dbo].[Administrator] (
    [ID] INT IDENTITY(1,1),
    [IsActive] BIT NOT NULL,
    [LastLogin] DATETIME NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);