-- Insert data
INSERT INTO Lokale (Name, Size, Capacity, MaxGroupsPerRoom, Equipment)
VALUES
    ('Room 101', 50, 30, 5, 'Projector, Whiteboard'),
    ('Conference Hall A', 200, 20, 10, 'Projector, Microphone, Podium'),
    ('Meeting Room B', 20, 30, 4, 'Whiteboard'),
    ('Training Room C', 30, 40, 5, 'Projector, Flipchart');


INSERT INTO Gruppe (Name, Size)
VALUES
    ('Staff Meeting', 20),
    ('Board Meeting', 10),
    ('Training Session', 25),
    ('Seminar', 150);


INSERT INTO Bruger (Role, Username, Password, Email, Description)
VALUES
    ('Admin', 'admin123', 'password123', 'admin@example.com', 'Administrator account'),
    ('User', 'user456', 'password456', 'user@example.com', 'Regular user account'),
    ('Manager', 'manager789', 'password789', 'manager@example.com', 'Managerial account');


INSERT INTO Booking (StartTime, EndTime, CancelDeadline)
VALUES
    ('2024-06-01 09:00:00', '2024-06-01 11:00:00', '2024-06-01 11:00:00'),
    ('2024-06-03 14:00:00', '2024-06-03 16:00:00', '2024-06-01 11:00:00'),
    ('2024-06-05 10:00:00', '2024-06-05 12:00:00', '2024-06-01 11:00:00'),
    ('2024-06-07 13:00:00', '2024-06-07 15:00:00', '2024-06-01 11:00:00');

INSERT INTO Underviser (Subject, Age)
VALUES
    ('WebDevelopment', 35),
    ('C#', 63),
    ('AdoNet', 52),
    ('Database', 43)

INSERT INTO Administrator (IsActive, LastLogin)
VALUES
    (1, '2024-06-01 10:00:00'),
    (1, '2024-06-02 14:00:00'),
    (0, '2024-06-03 09:00:00'),
    (0, '2024-06-03 09:30:00');
