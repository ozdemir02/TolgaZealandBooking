using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ZealandBooking.Models;

    public class ZealandBookingContext : DbContext
    {
        public ZealandBookingContext (DbContextOptions<ZealandBookingContext> options)
            : base(options)
        {
        }

        public DbSet<ZealandBooking.Models.Bruger> Bruger { get; set; } = default!;

        public DbSet<ZealandBooking.Models.Gruppe> Gruppe { get; set; } = default!;

        public DbSet<ZealandBooking.Models.Studerende> Studerende { get; set; } = default!;

        public DbSet<ZealandBooking.Models.Underviser> Underviser { get; set; } = default!;
    }
