﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ZealandBooking.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Administrator",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    LastLogin = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Administ__3214EC27E5FBFC87", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Bruger",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Role = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Username = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Bruger__3214EC27055B8B1A", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Lokale",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Size = table.Column<int>(type: "int", nullable: false),
                    Capacity = table.Column<int>(type: "int", nullable: false),
                    MaxGroupsPerRoom = table.Column<int>(type: "int", nullable: false),
                    Equipment = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Lokale__3214EC2798397AA7", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Gruppe",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Size = table.Column<int>(type: "int", nullable: false),
                    LokaleId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Gruppe__3214EC274E01E3BE", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Gruppe_Lokale_Id",
                        column: x => x.LokaleId,
                        principalTable: "Lokale",
                        principalColumn: "ID");
                });

            migrationBuilder.CreateTable(
                name: "Booking",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StartTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    EndTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    CancelDeadline = table.Column<DateTime>(type: "datetime", nullable: false),
                    LokaleId = table.Column<int>(type: "int", nullable: true),
                    BrugerId = table.Column<int>(type: "int", nullable: true),
                    GruppeId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Booking__3214EC27E8F4B4CA", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Booking_Bruger_Id",
                        column: x => x.BrugerId,
                        principalTable: "Bruger",
                        principalColumn: "ID");
                    table.ForeignKey(
                        name: "FK_Booking_Gruppe_Id",
                        column: x => x.GruppeId,
                        principalTable: "Gruppe",
                        principalColumn: "ID");
                    table.ForeignKey(
                        name: "FK_Booking_Lokale_Id",
                        column: x => x.LokaleId,
                        principalTable: "Lokale",
                        principalColumn: "ID");
                });

            migrationBuilder.CreateTable(
                name: "Studerende",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LokaleId = table.Column<int>(type: "int", nullable: true),
                    BrugerId = table.Column<int>(type: "int", nullable: true),
                    GruppeId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Studeren__3214EC278998B9B0", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Studerende_Bruger_Id",
                        column: x => x.BrugerId,
                        principalTable: "Bruger",
                        principalColumn: "ID");
                    table.ForeignKey(
                        name: "FK_Studerende_Gruppe_Id",
                        column: x => x.GruppeId,
                        principalTable: "Gruppe",
                        principalColumn: "ID");
                    table.ForeignKey(
                        name: "FK_Studerende_Lokale_Id",
                        column: x => x.LokaleId,
                        principalTable: "Lokale",
                        principalColumn: "ID");
                });

            migrationBuilder.CreateTable(
                name: "Underviser",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Subject = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Age = table.Column<int>(type: "int", nullable: true),
                    LokaleId = table.Column<int>(type: "int", nullable: true),
                    BrugerId = table.Column<int>(type: "int", nullable: true),
                    GruppeId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Undervis__3214EC279DF5B4F2", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Underviser_Bruger_Id",
                        column: x => x.BrugerId,
                        principalTable: "Bruger",
                        principalColumn: "ID");
                    table.ForeignKey(
                        name: "FK_Underviser_Gruppe_Id",
                        column: x => x.GruppeId,
                        principalTable: "Gruppe",
                        principalColumn: "ID");
                    table.ForeignKey(
                        name: "FK_Underviser_Lokale_Id",
                        column: x => x.LokaleId,
                        principalTable: "Lokale",
                        principalColumn: "ID");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Booking_BrugerId",
                table: "Booking",
                column: "BrugerId");

            migrationBuilder.CreateIndex(
                name: "IX_Booking_GruppeId",
                table: "Booking",
                column: "GruppeId");

            migrationBuilder.CreateIndex(
                name: "IX_Booking_LokaleId",
                table: "Booking",
                column: "LokaleId");

            migrationBuilder.CreateIndex(
                name: "UQ__Bruger__536C85E4AD29FF71",
                table: "Bruger",
                column: "Username",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Gruppe_LokaleId",
                table: "Gruppe",
                column: "LokaleId");

            migrationBuilder.CreateIndex(
                name: "IX_Studerende_BrugerId",
                table: "Studerende",
                column: "BrugerId");

            migrationBuilder.CreateIndex(
                name: "IX_Studerende_GruppeId",
                table: "Studerende",
                column: "GruppeId");

            migrationBuilder.CreateIndex(
                name: "IX_Studerende_LokaleId",
                table: "Studerende",
                column: "LokaleId");

            migrationBuilder.CreateIndex(
                name: "IX_Underviser_BrugerId",
                table: "Underviser",
                column: "BrugerId");

            migrationBuilder.CreateIndex(
                name: "IX_Underviser_GruppeId",
                table: "Underviser",
                column: "GruppeId");

            migrationBuilder.CreateIndex(
                name: "IX_Underviser_LokaleId",
                table: "Underviser",
                column: "LokaleId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Administrator");

            migrationBuilder.DropTable(
                name: "Booking");

            migrationBuilder.DropTable(
                name: "Studerende");

            migrationBuilder.DropTable(
                name: "Underviser");

            migrationBuilder.DropTable(
                name: "Bruger");

            migrationBuilder.DropTable(
                name: "Gruppe");

            migrationBuilder.DropTable(
                name: "Lokale");
        }
    }
}
