using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ZealandBooking.Models;

namespace ZealandBooking.Pages.Bookinger
{
    public class CreateModel : PageModel
    {
        private readonly ZealandBooking.Models.ZealandBookingDbContext _context;

        public CreateModel(ZealandBooking.Models.ZealandBookingDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
        ViewData["BrugerId"] = new SelectList(_context.Brugers, "Id", "Email");
        ViewData["GruppeId"] = new SelectList(_context.Gruppes, "Id", "Name");
        ViewData["LokaleId"] = new SelectList(_context.Lokales, "Id", "Equipment");
            return Page();
        }

        [BindProperty]
        public Booking Booking { get; set; } = default!;
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
          if (!ModelState.IsValid || _context.Bookings == null || Booking == null)
            {
                return Page();
            }

            _context.Bookings.Add(Booking);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
