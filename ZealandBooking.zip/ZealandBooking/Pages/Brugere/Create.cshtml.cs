using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ZealandBooking.Models;

namespace ZealandBooking.Pages_Brugere
{
    public class CreateModel : PageModel
    {
        private readonly ZealandBookingContext _context;

        public CreateModel(ZealandBookingContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Bruger Bruger { get; set; } = default!;
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
          if (!ModelState.IsValid || _context.Bruger == null || Bruger == null)
            {
                return Page();
            }

            _context.Bruger.Add(Bruger);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
