using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ZealandBooking.Models;

namespace ZealandBooking.Pages_Grupper
{
    public class DeleteModel : PageModel
    {
        private readonly ZealandBookingContext _context;

        public DeleteModel(ZealandBookingContext context)
        {
            _context = context;
        }

        [BindProperty]
      public Gruppe Gruppe { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Gruppe == null)
            {
                return NotFound();
            }

            var gruppe = await _context.Gruppe.FirstOrDefaultAsync(m => m.Id == id);

            if (gruppe == null)
            {
                return NotFound();
            }
            else 
            {
                Gruppe = gruppe;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null || _context.Gruppe == null)
            {
                return NotFound();
            }
            var gruppe = await _context.Gruppe.FindAsync(id);

            if (gruppe != null)
            {
                Gruppe = gruppe;
                _context.Gruppe.Remove(Gruppe);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
