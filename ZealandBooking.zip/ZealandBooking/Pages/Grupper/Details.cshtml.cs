using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ZealandBooking.Models;

namespace ZealandBooking.Pages_Grupper
{
    public class DetailsModel : PageModel
    {
        private readonly ZealandBookingContext _context;

        public DetailsModel(ZealandBookingContext context)
        {
            _context = context;
        }

      public Gruppe Gruppe { get; set; } = default!; 

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Gruppe == null)
            {
                return NotFound();
            }

            var gruppe = await _context.Gruppe.FirstOrDefaultAsync(m => m.Id == id);
            if (gruppe == null)
            {
                return NotFound();
            }
            else 
            {
                Gruppe = gruppe;
            }
            return Page();
        }
    }
}
