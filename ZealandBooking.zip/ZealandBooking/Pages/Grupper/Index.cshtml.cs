using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ZealandBooking.Models;

namespace ZealandBooking.Pages_Grupper
{
    public class IndexModel : PageModel
    {
        private readonly ZealandBookingContext _context;

        public IndexModel(ZealandBookingContext context)
        {
            _context = context;
        }

        public IList<Gruppe> Gruppe { get;set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.Gruppe != null)
            {
                Gruppe = await _context.Gruppe
                .Include(g => g.Lokale).ToListAsync();
            }
        }
    }
}
