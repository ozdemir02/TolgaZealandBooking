﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ZealandBooking.Models;

namespace ZealandBooking.Pages
{
	public class IndexModel : PageModel

	{
        private readonly ZealandBooking.Models.ZealandBookingDbContext _context;

        public IndexModel(ZealandBooking.Models.ZealandBookingDbContext context)
        {
            _context = context;
        }

        [BindProperty]
		public string? Username { get; set; }
        [BindProperty]
        public string? Password { get; set; }

        public string? Msg { get; set; }

		public void OnGet()
		{

		}
        public IActionResult OnPost(Bruger bruger)
        {
            if (Username == null || Password == null) {
                Msg = "Error, Fields cannot be Empty";
                return Page();
            }
            else {
                var User = from m in _context.Brugers select m;
                User = User.Where(s => s.Username.Contains(Username));
                if (User.Count() != 0)
                {
                    if (User.First().Password == Password)
                    {
                        Msg = "Welcome";
                        return RedirectToPage("Bookinger");
                    }
                }
                return Page();
            }
        }


    }
}