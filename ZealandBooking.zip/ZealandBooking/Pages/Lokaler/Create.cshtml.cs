using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ZealandBooking.Models;

namespace ZealandBooking.Pages.Lokaler
{
    public class CreateModel : PageModel
    {
        private readonly ZealandBooking.Models.ZealandBookingDbContext _context;

        public CreateModel(ZealandBooking.Models.ZealandBookingDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Lokale Lokale { get; set; } = default!;
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
          if (!ModelState.IsValid || _context.Lokales == null || Lokale == null)
            {
                return Page();
            }

            _context.Lokales.Add(Lokale);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
