using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ZealandBooking.Models;

namespace ZealandBooking.Pages.Lokaler
{
    public class DeleteModel : PageModel
    {
        private readonly ZealandBooking.Models.ZealandBookingDbContext _context;

        public DeleteModel(ZealandBooking.Models.ZealandBookingDbContext context)
        {
            _context = context;
        }

        [BindProperty]
      public Lokale Lokale { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Lokales == null)
            {
                return NotFound();
            }

            var lokale = await _context.Lokales.FirstOrDefaultAsync(m => m.Id == id);

            if (lokale == null)
            {
                return NotFound();
            }
            else 
            {
                Lokale = lokale;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null || _context.Lokales == null)
            {
                return NotFound();
            }
            var lokale = await _context.Lokales.FindAsync(id);

            if (lokale != null)
            {
                Lokale = lokale;
                _context.Lokales.Remove(Lokale);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
