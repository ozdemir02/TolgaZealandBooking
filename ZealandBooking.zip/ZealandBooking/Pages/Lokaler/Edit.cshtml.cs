using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ZealandBooking.Models;

namespace ZealandBooking.Pages.Lokaler
{
    public class EditModel : PageModel
    {
        private readonly ZealandBooking.Models.ZealandBookingDbContext _context;

        public EditModel(ZealandBooking.Models.ZealandBookingDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Lokale Lokale { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Lokales == null)
            {
                return NotFound();
            }

            var lokale =  await _context.Lokales.FirstOrDefaultAsync(m => m.Id == id);
            if (lokale == null)
            {
                return NotFound();
            }
            Lokale = lokale;
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(Lokale).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LokaleExists(Lokale.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool LokaleExists(int id)
        {
          return (_context.Lokales?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
