using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ZealandBooking.Models;

namespace ZealandBooking.Pages.Lokaler
{
    public class IndexModel : PageModel
    {
        private readonly ZealandBooking.Models.ZealandBookingDbContext _context;

        public IndexModel(ZealandBooking.Models.ZealandBookingDbContext context)
        {
            _context = context;
        }

        public IList<Lokale> Lokale { get;set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.Lokales != null)
            {
                Lokale = await _context.Lokales.ToListAsync();
            }
        }
    }
}
