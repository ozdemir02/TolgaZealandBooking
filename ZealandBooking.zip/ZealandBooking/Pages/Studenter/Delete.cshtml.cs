using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ZealandBooking.Models;

namespace ZealandBooking.Pages_Studenter
{
    public class DeleteModel : PageModel
    {
        private readonly ZealandBookingContext _context;

        public DeleteModel(ZealandBookingContext context)
        {
            _context = context;
        }

        [BindProperty]
      public Studerende Studerende { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Studerende == null)
            {
                return NotFound();
            }

            var studerende = await _context.Studerende.FirstOrDefaultAsync(m => m.Id == id);

            if (studerende == null)
            {
                return NotFound();
            }
            else 
            {
                Studerende = studerende;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null || _context.Studerende == null)
            {
                return NotFound();
            }
            var studerende = await _context.Studerende.FindAsync(id);

            if (studerende != null)
            {
                Studerende = studerende;
                _context.Studerende.Remove(Studerende);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
