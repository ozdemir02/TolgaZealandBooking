using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ZealandBooking.Models;

namespace ZealandBooking.Pages_Studenter
{
    public class IndexModel : PageModel
    {
        private readonly ZealandBookingContext _context;

        public IndexModel(ZealandBookingContext context)
        {
            _context = context;
        }

        public IList<Studerende> Studerende { get;set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.Studerende != null)
            {
                Studerende = await _context.Studerende
                .Include(s => s.Bruger)
                .Include(s => s.Gruppe)
                .Include(s => s.Lokale).ToListAsync();
            }
        }
    }
}
