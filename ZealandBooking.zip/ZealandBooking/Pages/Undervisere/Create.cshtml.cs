using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ZealandBooking.Models;

namespace ZealandBooking.Pages_Undervisere
{
    public class CreateModel : PageModel
    {
        private readonly ZealandBookingContext _context;

        public CreateModel(ZealandBookingContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
        ViewData["BrugerId"] = new SelectList(_context.Bruger, "Id", "Email");
        ViewData["GruppeId"] = new SelectList(_context.Gruppe, "Id", "Name");
        ViewData["LokaleId"] = new SelectList(_context.Set<Lokale>(), "Id", "Equipment");
            return Page();
        }

        [BindProperty]
        public Underviser Underviser { get; set; } = default!;
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
          if (!ModelState.IsValid || _context.Underviser == null || Underviser == null)
            {
                return Page();
            }

            _context.Underviser.Add(Underviser);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
