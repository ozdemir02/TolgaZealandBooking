using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ZealandBooking.Models;

namespace ZealandBooking.Pages_Undervisere
{
    public class EditModel : PageModel
    {
        private readonly ZealandBookingContext _context;

        public EditModel(ZealandBookingContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Underviser Underviser { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Underviser == null)
            {
                return NotFound();
            }

            var underviser =  await _context.Underviser.FirstOrDefaultAsync(m => m.Id == id);
            if (underviser == null)
            {
                return NotFound();
            }
            Underviser = underviser;
           ViewData["BrugerId"] = new SelectList(_context.Bruger, "Id", "Email");
           ViewData["GruppeId"] = new SelectList(_context.Gruppe, "Id", "Name");
           ViewData["LokaleId"] = new SelectList(_context.Set<Lokale>(), "Id", "Equipment");
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(Underviser).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UnderviserExists(Underviser.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool UnderviserExists(int id)
        {
          return (_context.Underviser?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
