using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ZealandBooking.Models;

namespace ZealandBooking.Pages_Undervisere
{
    public class IndexModel : PageModel
    {
        private readonly ZealandBookingContext _context;

        public IndexModel(ZealandBookingContext context)
        {
            _context = context;
        }

        public IList<Underviser> Underviser { get;set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.Underviser != null)
            {
                Underviser = await _context.Underviser
                .Include(u => u.Bruger)
                .Include(u => u.Gruppe)
                .Include(u => u.Lokale).ToListAsync();
            }
        }
    }
}
